import { useState } from "react";

export default function App() {
  const [counter, setCounter] = useState(0); 
  const [showProduct, setShowProduct] = useState(false); 

  const increase = () => {
    setCounter(counter + 1);
  };

  const toggleProductDisplay = () => {
    setShowProduct(!showProduct); 
  };

  return (
    <div className="bg-success">
      <p>Counter: {counter}</p>
      <div>
        <button onClick={increase}>Increase</button>
      </div>
      <div className="dis">
        <button onClick={toggleProductDisplay}>
          {showProduct ? "Hide Product" : "Show Product"}
        </button>
        {showProduct && (
          <div>
            <p>Name: iPhone X</p>
            <p>Price: $900</p>
            <p>Description: Good iPhone</p>
          </div>
        )}
      </div>
    </div>
  );
}